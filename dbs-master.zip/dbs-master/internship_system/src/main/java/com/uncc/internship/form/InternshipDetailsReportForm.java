package com.uncc.internship.form;

public class InternshipDetailsReportForm {
	
	
	   private String TITLE;
	   private String DESCRIPTION;
	   
	   private String COMPANYNAME;
	   private String NOOFOPENINGS;
	   private String INDUSTRY;
	public String getTITLE() {
		return TITLE;
	}
	public void setTITLE(String tITLE) {
		TITLE = tITLE;
	}
	public String getDESCRIPTION() {
		return DESCRIPTION;
	}
	public void setDESCRIPTION(String dESCRIPTION) {
		DESCRIPTION = dESCRIPTION;
	}
	public String getCOMPANYNAME() {
		return COMPANYNAME;
	}
	public void setCOMPANYNAME(String cOMPANYNAME) {
		COMPANYNAME = cOMPANYNAME;
	}
	public String getNOOFOPENINGS() {
		return NOOFOPENINGS;
	}
	public void setNOOFOPENINGS(String nOOFOPENINGS) {
		NOOFOPENINGS = nOOFOPENINGS;
	}
	public String getINDUSTRY() {
		return INDUSTRY;
	}
	public void setINDUSTRY(String iNDUSTRY) {
		INDUSTRY = iNDUSTRY;
	}
}
