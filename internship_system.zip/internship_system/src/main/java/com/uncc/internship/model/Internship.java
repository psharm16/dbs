package com.uncc.internship.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

//@Entity
//@Table(name = "Internship") 
public class Internship implements Serializable {


	private static final long serialVersionUID = -3465813074586302847L;

  //  @GeneratedValue
	//@Id
    //@Column(name = "InternshipId")
	private String InternshipId;
    private Date StartDate;
    private Date EndDate;
    private String Location;
    public String getInternshipId() {
		return InternshipId;
	}
	public void setInternshipId(String internshipId) {
		InternshipId = internshipId;
	}
	public Date getStartDate() {
		return StartDate;
	}
	public void setStartDate(Date startDate) {
		StartDate = startDate;
	}
	public Date getEndDate() {
		return EndDate;
	}
	public void setEndDate(Date endDate) {
		EndDate = endDate;
	}
	public String getLocation() {
		return Location;
	}
	public void setLocation(String location) {
		Location = location;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public Integer getHoursPerWeek() {
		return HoursPerWeek;
	}
	public void setHoursPerWeek(Integer hoursPerWeek) {
		HoursPerWeek = hoursPerWeek;
	}
	public Integer getNoOfOpenings() {
		return NoOfOpenings;
	}
	public void setNoOfOpenings(Integer noOfOpenings) {
		NoOfOpenings = noOfOpenings;
	}
	public String getTitle() {
		return Title;
	}
	public void setTitle(String title) {
		Title = title;
	}
	public String getPaidYorN() {
		return PaidYorN;
	}
	public void setPaidYorN(String paidYorN) {
		PaidYorN = paidYorN;
	}
	public String getCompanyID() {
		return CompanyID;
	}
	public void setCompanyID(String companyID) {
		CompanyID = companyID;
	}
	private String Description;
    private Integer HoursPerWeek;
    private Integer NoOfOpenings;
    private String Title;
    private String PaidYorN;
    private String CompanyID;
	
	
	/*
	 * `InternshipId` VARCHAR(15) NOT NULL,
  `StartDate` DATE NOT NULL,
  `EndDate` DATE NOT NULL,
  `Location` VARCHAR(20) NULL DEFAULT 'Not Decided',
  `Description` VARCHAR(1000) NULL DEFAULT NULL,
  `HoursPerWeek` INT(11) NOT NULL,
  `NoOfOpenings` INT(11) NOT NULL,
  `Title` VARCHAR(45) NOT NULL,
  `PaidYorN` VARCHAR(15) NOT NULL,
  `CompanyID` VARCHAR(15) NOT NULL,
  PRIMARY KEY (`InternshipId`),
  INDEX `CompanyID_idx` (`CompanyID` ASC),
  UNIQUE INDEX `InternshipId_UNIQUE` (`InternshipId` ASC),
INDEX `title` (`Title` ASC),
  CONSTRAINT `Internship_Company_CompanyID`
    FOREIGN KEY (`CompanyID`)
    REFERENCES `Internship_Inventory`.`Company` (`CompanyId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
	 */
	
	
}
