package com.uncc.internship.model;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import com.uncc.internship.model.Login.SecurityQuestion;

public class Application {

	private int ApplicationID;
	private String StudentID;
	private String InternshipID;
	
	public enum HIRE { 
    	yes, no, pending;
    }
    
    
 
    private HIRE HireOrNot;



	public int getApplicationID() {
		return ApplicationID;
	}



	public void setApplicationID(int applicationID) {
		ApplicationID = applicationID;
	}



	public String getStudentID() {
		return StudentID;
	}



	public void setStudentID(String studentID) {
		StudentID = studentID;
	}



	public String getInternshipID() {
		return InternshipID;
	}



	public void setInternshipID(String internshipID) {
		InternshipID = internshipID;
	}



	public HIRE getHireOrNot() {
		return HireOrNot;
	}



	public void setHireOrNot(HIRE hireOrNot) {
		HireOrNot = hireOrNot;
	}
	/* @Column(name="HireOrNot") 
    @Enumerated(EnumType.ORDINAL) 
    
	
	
	 * `ApplicationID` INT NOT NULL AUTO_INCREMENT,
  `HireOrNot` ENUM('pending', 'yes', 'no') NOT NULL DEFAULT 'pending',
  `StudentID` VARCHAR(15) NOT NULL,
  `InternshipID` VARCHAR(15) NOT NULL,
  PRIMARY KEY (`ApplicationID`),
  UNIQUE INDEX `applicationID_UNIQUE` (`ApplicationID` ASC),
  INDEX `studentNo_idx` (`StudentID` ASC),
  INDEX `InternshipIDs_idx` (`InternshipID` ASC),
  CONSTRAINT `Application_Student_studentId`
    FOREIGN KEY (`StudentID`)
    REFERENCES `Internship_Inventory`.`Student` (`StudentID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `Application_Internship_InternshipId`
    FOREIGN KEY (`InternshipID`)
    REFERENCES `Internship_Inventory`.`Internship` (`InternshipId`)
	 */
}
