package com.uncc.internship.model;

import javax.persistence.Column;

import java.io.Serializable;

import javax.persistence.CascadeType;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

//@Entity
//@Table(name = "UnpaidIntern", 
//uniqueConstraints = @UniqueConstraint(columnNames = {"InternshipID"}))
public class UnpaidIntern implements Serializable {


	private static final long serialVersionUID = -3465813074586302847L;

	/* `InternshipID` VARCHAR(15) NOT NULL,
	  `AcademicCredit` VARCHAR(45) NOT NULL,
	  PRIMARY KEY (`InternshipID`),
	  UNIQUE INDEX `InternshipID_UNIQUE` (`InternshipID` ASC),
	  CONSTRAINT `Internship_IDx`
	    FOREIGN KEY (`InternshipID`)
	    REFERENCES `Internship_Inventory`.`Internship` (`InternshipId`)
	    ON DELETE NO ACTION
	    ON UPDATE NO ACTION)*/

//@Id
//@Column(name = "InternshipID")
//@ManyToOne(cascade = CascadeType.ALL)
//@JoinColumn(name = "InternshipID")
private String InternshipID;

//@Column
private String AcademicCredit;

}
