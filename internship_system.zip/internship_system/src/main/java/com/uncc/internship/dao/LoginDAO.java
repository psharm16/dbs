package com.uncc.internship.dao;

import java.util.List;

import com.uncc.internship.model.IntershipDetailsView;
import com.uncc.internship.model.Login;

public interface LoginDAO {
	public boolean checkLogin(String userName, String userPassword);
	 void save(Login user);
	 public List<IntershipDetailsView> internshipDetailsReport();
	 public List<IntershipDetailsView> internshipDetailsReport(String searchValue);
}
