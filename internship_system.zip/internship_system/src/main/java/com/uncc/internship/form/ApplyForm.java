package com.uncc.internship.form;

public class ApplyForm {

	
	private String internshipId;
	private String role;
	private String studentID;
	private String hireOrNot;
	
	public String getInternshipId() {
		return internshipId;
	}
	public void setInternshipId(String internshipId) {
		this.internshipId = internshipId;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		
		this.role = role;
	}
	
	
}
