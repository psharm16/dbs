package com.uncc.internship.model;

import java.io.Serializable;
import java.util.Date;

public class Student implements Serializable {


	private static final long serialVersionUID = -3465813074586302847L;

	private String StudentID;
	private String Semester;
	private String Major;
	private String Minor;
	private Date GraduationYear;
	private Date EnrollmentYear;
	public String getStudentID() {
		return StudentID;
	}
	public void setStudentID(String studentID) {
		StudentID = studentID;
	}
	public String getSemester() {
		return Semester;
	}
	public void setSemester(String semester) {
		Semester = semester;
	}
	public String getMajor() {
		return Major;
	}
	public void setMajor(String major) {
		Major = major;
	}
	public String getMinor() {
		return Minor;
	}
	public void setMinor(String minor) {
		Minor = minor;
	}
	public Date getGraduationYear() {
		return GraduationYear;
	}
	public void setGraduationYear(Date graduationYear) {
		GraduationYear = graduationYear;
	}
	public Date getEnrollmentYear() {
		return EnrollmentYear;
	}
	public void setEnrollmentYear(Date enrollmentYear) {
		EnrollmentYear = enrollmentYear;
	}
	public float getGPA() {
		return GPA;
	}
	public void setGPA(float gPA) {
		GPA = gPA;
	}
	private float GPA;
	
	/*
	 *   `StudentID` VARCHAR(15) NOT NULL,
  `Semester` VARCHAR(45) NULL,
  `Major` VARCHAR(45) NULL,
  `Minor` VARCHAR(45) NULL,
  `GraduationYear` YEAR NULL,
  `EnrollmentYear` YEAR NULL,
  `GPA` DECIMAL NULL,
  PRIMARY KEY (`StudentID`),
  CONSTRAINT `student_id`
    FOREIGN KEY (`StudentID`)
    REFERENCES `Internship_Inventory`.`Person` (`ID`)
	 */
}
