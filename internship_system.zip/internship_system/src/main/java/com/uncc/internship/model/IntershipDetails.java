package com.uncc.internship.model;

public class IntershipDetails {

	
	/*private int TITLE;
	private DESCRIPTION` INT, `COMPANYNAME` INT, `NOOFOPENINGS` INT, `INDUSTRY` INT);*/

}
