package com.uncc.internship.model;

import java.io.Serializable;

public class InternshipSkill implements Serializable {


	private static final long serialVersionUID = -3465813074586302847L;


	public String getSkillID() {
		return SkillID;
	}
	public void setSkillID(String skillID) {
		SkillID = skillID;
	}
	public String getInternshipID() {
		return InternshipID;
	}
	public void setInternshipID(String internshipID) {
		InternshipID = internshipID;
	}
	private String SkillID;
	private String InternshipID;
	/*
	 * `SkillID` VARCHAR(15) NOT NULL,
  `InternshipID` VARCHAR(15) NOT NULL,
  PRIMARY KEY (`SkillID`, `InternshipID`),
  INDEX `InternshipID_idx` (`InternshipID` ASC),
  CONSTRAINT `SkillId`
    FOREIGN KEY (`SkillID`)
    REFERENCES `Internship_Inventory`.`Skills` (`SkillID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `InternshipSkill_Internship_InternshipID`
    FOREIGN KEY (`InternshipID`)
    REFERENCES `Internship_Inventory`.`Internship` (`InternshipId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
	 */
}
