package com.uncc.internship.model;

import java.io.Serializable;

public class Person implements Serializable {


	private static final long serialVersionUID = -3465813074586302847L;

	private String ID;
	private String Name;
	private String Cell;
	private String Email;
	private String Address;
	private String SSN;
	private String LoginID;
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getCell() {
		return Cell;
	}
	public void setCell(String cell) {
		Cell = cell;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getSSN() {
		return SSN;
	}
	public void setSSN(String sSN) {
		SSN = sSN;
	}
	public String getLoginID() {
		return LoginID;
	}
	public void setLoginID(String loginID) {
		LoginID = loginID;
	}
	
	
	/*
	 *  `ID` VARCHAR(15) NOT NULL,
  `Name` VARCHAR(45) NULL DEFAULT NULL,
  `Cell` VARCHAR(15) NULL DEFAULT NULL,
  `Email` VARCHAR(45) NULL DEFAULT NULL,
  `Address` VARCHAR(45) NULL DEFAULT NULL,
  `SSN` VARCHAR(15) NULL DEFAULT NULL,
  `LoginID` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE INDEX `ID_UNIQUE` (`ID` ASC),
  UNIQUE INDEX `Email_UNIQUE` (`Email` ASC),
  INDEX `LoginID_idx` (`LoginID` ASC),
  CONSTRAINT `LoginID`
    FOREIGN KEY (`LoginID`)
    REFERENCES `internship_inventory`.`login` (`LoginId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
	 */
}
