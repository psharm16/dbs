package com.uncc.internship.model;

public class Employee {

}
