package com.uncc.internship.model;

import java.io.Serializable;

public class Login implements Serializable {

	private static final long serialVersionUID = -3465813074586302847L;

	
	private String LoginId;

	private String Password;
	
	private String Security_Answer;

	public enum SecurityQuestion {
		FIRST_MOVIE("FIRST_MOVIE"), city("city");
		String question;
		SecurityQuestion(String name){
			this.question=name;
		}
		SecurityQuestion valueOf() {
			return null;
			
		}
	}

	String FIRST_MOVIE = "FIRST MOVIE";

	private String security_Question;

	public String getSecurity_Question() {
		return security_Question;
	}

	public void setSecurity_Question(String security_Question) {
		this.security_Question = security_Question;
	}

	/*public SecurityQuestion getSecurityQuestion() {
		return new SecurityQuestion()
	}*/
	public enum AccessRights {
		ADMIN, USER;
	}

	private AccessRights Access_Rights;

	public AccessRights getAccess_Rights() {
		return Access_Rights;
	}

	public void setAccess_Rights(AccessRights access_Rights) {
		Access_Rights = access_Rights;
	}

	public String getLoginId() {
		return LoginId;
	}

	public void setLoginId(String loginId) {
		LoginId = loginId;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public String getSecurity_Answer() {
		return Security_Answer;
	}

	public void setSecurity_Answer(String security_Answer) {
		Security_Answer = security_Answer;
	}

}
