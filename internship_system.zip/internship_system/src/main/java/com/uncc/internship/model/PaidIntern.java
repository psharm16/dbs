package com.uncc.internship.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

//@Entity
//@Table(name = "PaidIntern", 
//uniqueConstraints = @UniqueConstraint(columnNames = {"InternshipID"}))
public class PaidIntern implements Serializable {


	private static final long serialVersionUID = -3465813074586302847L;
/*
 * `InternshipID` VARCHAR(15) NOT NULL,
  `TotalSalary` DOUBLE NULL,
  `WorkType` VARCHAR(45) NULL,
  PRIMARY KEY (`InternshipID`),
  UNIQUE INDEX `InternshipID_UNIQUE` (`InternshipID` ASC),
  CONSTRAINT `InternshipIDx`
    FOREIGN KEY (`InternshipID`)
    REFERENCES `Internship_Inventory`.`Internship` (`InternshipId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
 */
	
	//@Id
	//@Column(name = "InternshipID")
	//@ManyToOne(cascade = CascadeType.ALL)
	//@JoinColumn(name = "InternshipID")
	private String InternshipID;

	//@Column
	private Double TotalSalary;
	
	//@Column
	private String WorkType;
}
