package com.uncc.internship.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: IntershipDetailsView
 *
 */

public class IntershipDetailsView implements Serializable {

	
	public String getTITLE() {
		return TITLE;
	}
	public void setTITLE(String tITLE) {
		TITLE = tITLE;
	}
	public String getDESCRIPTION() {
		return DESCRIPTION;
	}
	public void setDESCRIPTION(String dESCRIPTION) {
		DESCRIPTION = dESCRIPTION;
	}
	public String getCOMPANYNAME() {
		return COMPANYNAME;
	}
	public void setCOMPANYNAME(String cOMPANYNAME) {
		COMPANYNAME = cOMPANYNAME;
	}
	public String getNOOFOPENINGS() {
		return NOOFOPENINGS;
	}
	public void setNOOFOPENINGS(String nOOFOPENINGS) {
		NOOFOPENINGS = nOOFOPENINGS;
	}
	public String getINDUSTRY() {
		return INDUSTRY;
	}
	public void setINDUSTRY(String iNDUSTRY) {
		INDUSTRY = iNDUSTRY;
	}
	private static final long serialVersionUID = 1L;

	public IntershipDetailsView() {
		super();
	}
/*
 * USE `Internship_Inventory`;
CREATE  OR REPLACE VIEW `IntershipDetails` AS select INTE.TITLE, INTE.DESCRIPTION, CO.COMPANYNAME,
INTE.NOOFOPENINGS,CO.INDUSTRY FROM COMPANY AS CO INNER JOIN INTERNSHIP AS INTE ON INTE.COMPANYID
=CO.COMPANYID;
USE `Internship_Inventory`;
 */
	
   private String TITLE;
   private String DESCRIPTION;
   
   private String COMPANYNAME;
   private String NOOFOPENINGS;
   private String INDUSTRY;
   
}
