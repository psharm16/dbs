package com.uncc.internship.model;

public class Skills {

	
	/* `SkillID` VARCHAR(15) NOT NULL,
	  `SkillDescription` VARCHAR(45) NULL,
	  PRIMARY KEY (`SkillID`))*/
	private String SkillID;
	private String SkillDescription;
	public String getSkillID() {
		return SkillID;
	}
	public void setSkillID(String skillID) {
		SkillID = skillID;
	}
	public String getSkillDescription() {
		return SkillDescription;
	}
	public void setSkillDescription(String skillDescription) {
		SkillDescription = skillDescription;
	}
}
