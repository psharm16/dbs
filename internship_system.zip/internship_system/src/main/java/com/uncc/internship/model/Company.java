package com.uncc.internship.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Table;


public class Company implements Serializable {


	private static final long serialVersionUID = -3465813074586302847L;
	 
	private String CompanyId;
	public String getCompanyId() {
		return CompanyId;
	}
	public void setCompanyId(String companyId) {
		CompanyId = companyId;
	}
	public String getCompanyName() {
		return CompanyName;
	}
	public void setCompanyName(String companyName) {
		CompanyName = companyName;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getCell() {
		return Cell;
	}
	public void setCell(String cell) {
		Cell = cell;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public String getIndustry() {
		return Industry;
	}
	public void setIndustry(String industry) {
		Industry = industry;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	private String CompanyName="Anonymous";
	private String Address;
	private String Cell;
	private String Description;
	private String Industry;
	private String Email;
	
	
	/*
	 *  `CompanyId` VARCHAR(15) NOT NULL,
  `CompanyName` VARCHAR(45) NULL DEFAULT 'Anonymous',
  `Address` VARCHAR(45) NULL,
  `Cell` VARCHAR(15) NULL DEFAULT NULL,
  `Description` VARCHAR(1000) NULL,
  `Industry` VARCHAR(45) NULL,
  `Email` VARCHAR(45) NULL,
  PRIMARY KEY (`CompanyId`),
  INDEX `industry` USING BTREE (`Industry` ASC),
  UNIQUE INDEX `CompanyId_UNIQUE` (`CompanyId` ASC))
	 */
}
