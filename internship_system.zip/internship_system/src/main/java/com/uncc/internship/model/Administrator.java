package com.uncc.internship.model;

public class Administrator {

}
